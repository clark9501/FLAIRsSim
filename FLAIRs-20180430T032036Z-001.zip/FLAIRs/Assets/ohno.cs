﻿using UnityEngine;
using System.Collections;

public class ohno : MonoBehaviour
{
    public float MoveSpeed;
    private Rigidbody rb;

    private Vector3 moveInput;
    private Vector3 moveVelocity;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
    void Update()
    {
        moveInput = new Vector3(Input.GetAxisRaw("Horizontal"), 0f, Input.GetAxisRaw("Vertical"));
        moveVelocity = moveInput * MoveSpeed;
    }

    private void FixedUpdate()
    {
        rb.velocity = moveVelocity;
    }
}
