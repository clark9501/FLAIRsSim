﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ANH : MonoBehaviour
{

    public Rigidbody rb;

    public float rotateForce = 2000f;
    public float sidewaysForce = 500f;
    public float maxVelocity = 1500;

    void Start()
    {

    }

    void FixedUpdate()
    {

        if (Input.GetKey("l"))
        {
            rb.AddRelativeForce(sidewaysForce * Time.deltaTime, 0, 0);
        }

        if (Input.GetKey("j"))
        {
            rb.AddRelativeForce(-sidewaysForce * Time.deltaTime, 0, 0);
        }

        if (Input.GetKey(","))
        {
            rb.AddRelativeForce(0, 0, -sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("i"))
        {
            rb.AddRelativeForce(0, 0, sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("u"))
        {
            rb.AddRelativeForce(-sidewaysForce * Time.deltaTime, 0, sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("o"))
        {
            rb.AddRelativeForce(sidewaysForce * Time.deltaTime, 0, sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("m"))
        {
            rb.AddRelativeForce(-sidewaysForce * Time.deltaTime, 0, -sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("."))
        {
            rb.AddRelativeForce(sidewaysForce * Time.deltaTime, 0, -sidewaysForce * Time.deltaTime);
        }


        if (Input.GetKey("7"))
        {
            rb.AddRelativeTorque(0, -rotateForce * Time.deltaTime, 0);
        }
        if (Input.GetKey("8"))
        {
            rb.AddRelativeTorque(0, rotateForce * Time.deltaTime, 0);
        }

    }
}
