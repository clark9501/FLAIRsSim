﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TRWIH : MonoBehaviour
{
//HELLO VIP TEAM
//WHADDUP
//WELCOME TO THE PLAYER MOVEMENT CONTROL ROOM
//THE ROOM WHERE IT HAPPENS
//I WANNA BE IN
//THE ROOM WHERE IT HAPPENS

        //hi phil
    public Rigidbody rb;

    public float rotateForce = 2000f; 
    public float sidewaysForce = 500f;
    public float maxVelocity = 1500;

    void Start()
    {
 
    }

    void FixedUpdate()
    {

        if (Input.GetKey("d"))
        {
            rb.AddRelativeForce(sidewaysForce * Time.deltaTime, 0, 0);
        }

        if (Input.GetKey("a"))
        {
            rb.AddRelativeForce(-sidewaysForce * Time.deltaTime, 0, 0);
        }

        if (Input.GetKey("x"))
        {
            rb.AddRelativeForce(0, 0, -sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("w"))
        {
            rb.AddRelativeForce(0, 0, sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("q"))
        {
            rb.AddRelativeForce(-sidewaysForce * Time.deltaTime, 0, sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("e"))
        {
            rb.AddRelativeForce(sidewaysForce * Time.deltaTime, 0, sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("z"))
        {
            rb.AddRelativeForce(-sidewaysForce * Time.deltaTime, 0, -sidewaysForce * Time.deltaTime);
        }

        if (Input.GetKey("c"))
        {
            rb.AddRelativeForce(sidewaysForce * Time.deltaTime, 0, -sidewaysForce * Time.deltaTime);
        }


        if (Input.GetKey("1"))
        {
            rb.AddRelativeTorque(0, -rotateForce * Time.deltaTime, 0);
        }
        if (Input.GetKey("2"))
        {
            rb.AddRelativeTorque(0, rotateForce * Time.deltaTime, 0);
        }

    }
}
